This directory holds user-defined configuration for UI modules.

Each file should be named <module>.js for variables and <module>.css for
layout/style settings where <module> is the name of the module that will
load the config.

Copy and rename the <module>-example.js file to <module>.js for an easy
starting point.