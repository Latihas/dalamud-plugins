const firstHeadmarker = parseInt('004F', 16);
const getHeadmarkerId = (data, matches) => {
    if (typeof data.decOffset === 'undefined')
        data.decOffset = parseInt(matches.id, 16) - firstHeadmarker;
    return (parseInt(matches.id, 16) - data.decOffset).toString(16).toUpperCase().padStart(4, '0');
};





Options.Triggers.push({
    zoneId: ZoneId.AsphodelosTheThirdCircleSavage,
    overrideTimelineFile: true,
    timelineFile: 'P3S.txt',
    initData: () => {
        return {
            小鸟位置: {
                上:'',
                下:'',
                左:'',
                右:''
            },
            人位置: {
                上:'',
                下:'',
                左:'',
                右:''
            },
        };
    },
    timelineTriggers: [
        {
            id: 'P3S 灵泉第二组靠近',
            regex: '灵泉',
            condition: (data, _matches) => {
                if(!data.party.isHealer(data.me))return true;
            },
            beforeSeconds: -3,
            infoText: '第二组靠近',
        },
        {
            id: 'P3S 灵泉第三组靠近',
            regex: '灵泉',
            condition: (data, _matches) => {
                if(!data.party.isHealer(data.me))return true;
            },
            beforeSeconds: -8,
            infoText: '第三组靠近',
        },
        {
            id: 'P3S 转盘',
            regex: /^转盘$/,
            beforeSeconds: 3,
            infoText: '转盘三穿一'
        },
        {
            id: 'P3S 万变火波',
            regex: 'BOSS喷火',
            beforeSeconds: 7,
            infoText: '引导喷火'
        },
        {
            id: 'P3S 火龙卷黄圈',
            regex: '集合放黄圈',
            beforeSeconds: 4,
            infoText: '集合放黄圈'
        },
        {
            id: 'P3S 黑龙卷',
            regex: '黑龙卷击退',
            beforeSeconds: 5,
            infoText: '黑龙卷 击退'
        },
    ],

    triggers: [
        {
            id: 'P3S Headmarker Tracker',
            type: 'HeadMarker',
            netRegex: NetRegexes.headMarker({}),
            condition: (data) => data.decOffset === undefined,
            // Unconditionally set the first headmarker here so that future triggers are conditional.
            run: (data, matches) => getHeadmarkerId(data, matches),
        },
        {
            id: 'P3S Scorched Exaltation',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6706', capture: false }),
            response: Responses.aoe(),
        },
        {
            id: 'P3S Darkened Fire',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '66B9', capture: false }),
            infoText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'Fire Positions',
                    de: 'Feuer-Positionen',
                    fr: 'Positions feu',
                    ja: '黒い炎の位置に散開',
                    cn: '放小怪',
                    ko: '불꽃 산개 위치로',
                },
            },
        },
        {
            id: 'P3S Heat of Condemnation',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6700',  capture: false }),
            alertText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'Tank Tethers',
                    de: 'Tank-Verbindungen',
                    fr: 'Liens Tank',
                    ja: 'タンク線取り',
                    cn: '坦克截线',
                    ko: '탱커 선 가로채기',
                },
            },
        },
        {
            id: 'P3S Experimental Fireplume Rotating Cast',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '66C0', capture: false }),
            infoText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'Get Middle (then rotate)',
                    de: 'Geh in die Mitte (und rotiere dann)',
                    fr: 'Placez-vous au milieu (puis tournez)',
                    ja: '中央 → 小玉・ぐるぐる',
                    cn: '九连环，场中集合',
                    ko: '가운데 → 작은 구슬, 시바 장판',
                },
            },
        },
        {
            id: 'P3S Experimental Fireplume Out Cast',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '66BE', capture: false }),
            infoText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'Get Middle (then out)',
                    de: 'Geh in die Mitte (und dann raus)',
                    fr: 'Placez-vous au milieu (puis sortez)',
                    ja: '中央 → 大玉・離れる',
                    cn: '大钢铁，场中集合',
                    ko: '가운데 → 큰 구슬, 밖으로',
                },
            },
        },
        {
            id: 'P3S Experimental Fireplume Out Marker',
            type: 'Ability',
            netRegex: NetRegexes.ability({ id: '66BE', capture: false }),
            // goldfish brain needs an extra "get out" call
            response: Responses.getOut(),
        },
        {
            id: 'P3S Right Cinderwing',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6702', capture: false }),
            response: Responses.goLeft(),
        },
        {
            id: 'P3S Left Cinderwing',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6703', capture: false }),
            response: Responses.goRight(),
        },
        {
            id: 'P3S Flare of Condemnation',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '66FB', capture: false }),
            alertText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'Sides + Spread',
                    de: 'Seiten + Verteilen',
                    fr: 'Côtés + Dispersez-vous',
                    ja: '横側安置：散開',
                    cn: '去两侧 + 分散',
                    ko: '바깥쪽에서 산개',
                },
            },
        },
        {
            id: 'P3S Spark of Condemnation',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '66FC', capture: false }),
            alertText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'Middle Pairs',
                    de: 'Mittlere Paare',
                    fr: 'Paires au milieu',
                    ja: '中央直線安置：二人組で頭割り',
                    cn: '去中间 + 分摊',
                    ko: '가운데서 짝꿍끼리 산개',
                },
            },
        },
        {
            id: 'P3S Bright Fire Marker and Fledgling Flights',
            type: 'HeadMarker',
            netRegex: NetRegexes.headMarker({}),
            condition: Conditions.targetIsYou(),
            alertText: (data, matches, output) => {
                const id = getHeadmarkerId(data, matches);
                return {
                    '004F': output.num1(),
                    '0050': output.num2(),
                    '0051': output.num3(),
                    '0052': output.num4(),
                    '0053': output.num5(),
                    '0054': output.num6(),
                    '0055': output.num7(),
                    '0056': output.num8(),
                    '006B': data.deathsToll ? output.west() : output.east(),
                    '006C': data.deathsToll ? output.east() : output.west(),
                    '006D': data.deathsToll ? output.north() : output.south(),
                    '006E': data.deathsToll ? output.south() : output.north(),
                }[id];
            },
            outputStrings: {
                num1: '1号 1号',
                num2: '2号 2号',
                num3: '3号 3号',
                num4: '4号 4号',
                num5: '5号 5号，和1号一组',
                num6: '6号 6号，和2号一组',
                num7: '7号 7号，和3号一组',
                num8: '8号 8号，和4号一组',
                east: '右 → 东',
                west: '左 ← 西',
                south: '下 ↓ 南',
                north: '上 ↑ 北',
            },
        },
        {   //大鸟连线
            id: 'P3S Sunbird Tether Collector',
            type: 'Tether',
            // 0039 when pink, 0001 when stretched purple.
            // TODO: in general, it seems like the tethers are picked to start unstretched,
            // but plausibly you could create a scenario where one starts stretched?
            netRegex: NetRegexes.tether({ id: '0039' }),
            alertText: (data,matches) => {
                if(matches.target == data.me){
                    if (['陽炎鳥', 'Sunbird','阳炎鸟'].includes(matches.source)){
                        if(data.小鸟位置.下 == matches.sourceId) return '上 ↑ 北';
                        if(data.小鸟位置.上 == matches.sourceId) return '下 ↓ 南';
                        if(data.小鸟位置.右 == matches.sourceId) return '左 ← 西';
                        if(data.小鸟位置.左 == matches.sourceId) return '右 → 东';
                    }
                    else{
                        if(data.人位置.上 == matches.source) return '上 ↑ 北';
                        if(data.人位置.下 == matches.source) return '下 ↓ 南';
                        if(data.人位置.左 == matches.source) return '左 ← 西';
                        if(data.人位置.右 == matches.source) return '右 → 东';
                    };
                };
            },
            run: (data, matches) => {
                if(data.小鸟位置.上 === matches.sourceId) data.人位置.上 = matches.target;
                if(data.小鸟位置.下 === matches.sourceId) data.人位置.下 = matches.target;
                if(data.小鸟位置.左 === matches.sourceId) data.人位置.左 = matches.target;
                if(data.小鸟位置.右 === matches.sourceId) data.人位置.右 = matches.target;
            },
        },
        {   //获取鸟出生位置
            id: 'P3S Sunbird Collector',
            type: 'AddedCombatant',
            // Small birds are 13633, and big birds are 13635.
            netRegex: NetRegexes.addedCombatantFull({ npcBaseId: '13635'  }),
            run: (data, matches) => {
                if (matches.y*1 <= 95) data.小鸟位置.上 = matches.id;
                if (matches.y*1 >= 105) data.小鸟位置.下 = matches.id;
                if (matches.x*1 <= 95) data.小鸟位置.左 = matches.id;
                if (matches.x*1 >= 105) data.小鸟位置.右 = matches.id;
            },
        },
        {
            id: 'P3S Sunbird Tether',
            type: 'Tether',
            netRegex: NetRegexes.tether({ id: ['0039', '0001'] }),
            condition: Conditions.targetIsYou(),
            suppressSeconds: 9999,
            disabled:true,
        },
        {
            id: 'P3S Dead Rebirth',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '66E4', capture: false }),
            response: Responses.bigAoe(),
        },
        {
            id: 'P3S Experimental Gloryplume Rotate Cast',
            type: 'StartsUsing',
            // 66CA (self) -> 66CB (rotating) -> etc
            netRegex: NetRegexes.startsUsing({ id: '66CA', capture: false }),
            alertText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'Get Middle (then rotate)',
                    de: 'Geh in die Mitte (und rotiere dann)',
                    fr: 'Placez-vous au milieu (puis tournez)',
                    ja: '中央 → 小玉・ぐるぐる',
                    cn: '九连环 + 前后分组远离',
                    ko: '가운데 → 작은 구슬, 시바 장판',
                },
            },
        },
        {
            id: 'P3S Experimental Gloryplume Out Cast',
            type: 'StartsUsing',
            // 66C6 (self) -> 66C7 (middle) -> etc
            netRegex: NetRegexes.startsUsing({ id: '66C6', capture: false }),
            alertText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'Get Middle (then out)',
                    de: 'Geh in die Mitte (und dann raus)',
                    fr: 'Placez-vous au milieu (puis sortez)',
                    ja: '中央 → 大玉・離れる',
                    cn: '大钢铁 + 前后分组远离',
                    ko: '가운데 → 큰 구슬, 밖으로',
                },
            },
        },
        {
            id: 'P3S Experimental Gloryplume Out',
            type: 'Ability',
            // 66C6 (self) -> 66C7 (middle) -> etc
            netRegex: NetRegexes.ability({ id: '66C6', capture: false }),
            response: Responses.getOut(),
        },
        {
            id: 'P3S Experimental Gloryplume Stack',
            type: 'Ability',
            // 66CA (self) -> 66CB (rotating) -> 66CC (instant) -> 66CD (stacks)
            // 66C6 (self) -> 66C7 (middle) -> 66CC (instant) -> 66CD (stacks)
            netRegex: NetRegexes.ability({ id: '66CC', capture: false }),
            infoText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'Stacks After',
                    de: 'Danach sammeln',
                    fr: 'Packez-vous après',
                    ja: 'あとで頭割り',
                    cn: '然后分摊',
                    ko: '그 다음 쉐어',
                },
            },
        },
        {
            id: 'P3S Experimental Gloryplume Spread',
            type: 'Ability',
            // 66CA (self) -> 66CB (rotating) -> 66C8 (instant) -> 66C9 (spread)
            // 66C6 (self) -> 66C7 (middle) -> 66C8 (instant) -> 66C9 (spread)
            netRegex: NetRegexes.ability({ id: '66C8', capture: false }),
            infoText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'Spread After',
                    de: 'Danach verteilen',
                    fr: 'Dispersez-vous après',
                    ja: 'あとで散開',
                    cn: '然后分散',
                    ko: '그 다음 산개',
                },
            },
        },
        {
            id:'P3S 灵泉',
            type:'startsUsing',
            netRegex: NetRegexes.startsUsing({ id: '66E7', capture: false }),
            infoText:'准备灵泉，第一组靠近',
        },
        {
            id: 'P3S Sun\'s Pinion',
            type: 'HeadMarker',
            netRegex: NetRegexes.headMarker({}),
            disabled:true,
            condition: (data, matches) => data.me === matches.target && getHeadmarkerId(data, matches) === '007A',
        },
        {
            id: 'P3S Firestorms of Asphodelos',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '66F0', capture: false }),
            response: Responses.bigAoe(),
        },
        {
            id: 'P3S Experimental Ashplume Stacks',
            type: 'Ability',
            // 66C2 cast -> 66C3 stacks damage
            netRegex: NetRegexes.ability({ id: '66C2', capture: false }),
            alertText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'Stacks',
                    de: 'Sammeln',
                    fr: 'Packez-vous',
                    ja: '頭割り',
                    cn: '分摊',
                    ko: '쉐어',
                },
            },
        },
        {
            id: 'P3S Experimental Ashplume Spread',
            type: 'Ability',
            // 66C4 cast -> 66C5 spread damage
            netRegex: NetRegexes.ability({ id: '66C4', capture: false }),
            alertText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'Spread',
                    de: 'Verteilen',
                    fr: 'Dispersez-vous',
                    ja: '散開',
                    cn: '分散',
                    ko: '산개',
                },
            },
        },
        {
            id: 'P3S Death\'s Toll Number',
            type: 'GainsEffect',
            netRegex: NetRegexes.gainsEffect({ effectId: ['ACA'], capture: true }),
            // Force this to only run once without Conditions.targetIsYou()
            // in case user is dead but needs to place fledgling flight properly
            preRun: (data) => data.deathsToll = true,
            // Delay callout until Ashen Eye start's casting
            delaySeconds: 15.5,
            infoText: (data, matches) => {
                if (matches.target === data.me && !data.deathsTollPending) {
                    data.deathsTollPending = true;
                    return {
                        '01': '1号buff，站小怪后面',
                        '02': '2号buff，站斜点方块',
                        '04': '4号buff，站场中',
                    }[matches.count];
                }
            },
        },
    ],
});
