const tetherOutputStrings = {
    purpleTether: {
        en: 'Purple Tether',
        cn: '紫色',
    },
    orangeTether: {
        en: 'Orange Tether',
        cn: '红色',
    },
    greenTether: {
        en: 'Green Tether',
        cn: '绿色',
    },
    blueTether: {
        en: 'Blue Tether',
        cn: '蓝色',
    },
};
const tetherOutputStringsAct = {
    purpleTether: {
        2: '远离',
        4: '，走 1 个塔',
    },
    orangeTether: {
        2: '红色',
    },
    greenTether: {
        2: '绿色',
    },
    blueTether: {
        4: '，走 3 个塔',
    },
};
const curtainCallOutputStrings = {
    group: {
        en: 'Group ${num}',
        cn: '第 ${num} 组',
    },
};
const sixTTS ='出去出去';

function nametocnjob(name,data){
    let re;
    switch (data.party.jobName(name)){
        case 'PLD':
            re = '骑士';
            break;
        case 'MNK':
            re = '武僧';
            break;
        case 'WAR':
            re = '战士';
            break;
        case 'DRG':
            re = '龙骑';
            break;
        case 'BRD':
            re = '诗人';
            break;
        case 'WHM':
            re = '白魔';
            break;
        case 'BLM':
            re = '黑魔';
            break;
        case 'SMN':
            re = '召唤';
            break;
        case 'SCH':
            re = '学者';
            break;
        case 'NIN':
            re = '忍者';
            break;
        case 'MCH':
            re = '机工';
            break;
        case 'DRK':
            re = '黑骑';
            break;
        case 'AST':
            re = '占星';
            break;
        case 'SAM':
            re = '武士';
            break;
        case 'RDM':
            re = '赤魔';
            break;
        case 'GNB':
            re = '枪刃';
            break;
        case 'DNC':
            re = '舞者';
            break;
        case 'RPR':
            re = '镰刀';
            break;
        case 'SGE':
            re = '贤者';
            break;
        case 'BLU':
            re = '青魔';
            break;
    };
    // 如果有重复职业，则播报职业+ID
    // t同职业
    if(data.party.roleToPartyNames_.tank[0] == data.party.roleToPartyNames_.tank[1]){
        return re + ' ' + data.ShortName(name);
    };
    // H同职业
    if(data.party.roleToPartyNames_.healer[0] == data.party.roleToPartyNames_.healer[1]){
        return re + ' ' + data.ShortName(name);
    };
    // DPS同职业
    for (let i=0;i < 3;i++ ) {
        for (let a=1 ; a < 4 ;a ++) {
            if (i==a){
                continue;
            };
            if(data.party.roleToPartyNames_.dps[i] == data.party.roleToPartyNames_.dps[a]){
                return re + ' ' + data.ShortName(name);
            };
        };       
    };
    // 没有同职业，播报职业
    return re;
};
// Due to changes introduced in patch 5.2, overhead markers now have a random offset
// added to their ID. This offset currently appears to be set per instance, so
// we can determine what it is from the first overhead marker we see.
// The first 1B marker in the encounter is an Elegant Evisceration (00DA).
// The first 1B marker in the phase 2 encounter could be one of three:
// Purple, Green, Orange color tethers (012D, 012E, 012F)
const firstHeadmarker = parseInt('00DA', 16);
const purpleMarker = parseInt('012D', 16);
const getHeadmarkerId = (data, matches) => {
    // If we naively just check !data.decOffset and leave it, it breaks if the first marker is 00DA.
    // (This makes the offset 0, and !0 is true.)
    if (typeof data.decOffset === 'undefined')
        data.decOffset = parseInt(matches.id, 16) - firstHeadmarker;
    // The leading zeroes are stripped when converting back to string, so we re-add them here.
    // Fortunately, we don't have to worry about whether or not this is robust,
    // since we know all the IDs that will be present in the encounter.
    return (parseInt(matches.id, 16) - data.decOffset).toString(16).toUpperCase().padStart(4, '0');
};
Options.Triggers.push({
    zoneId: ZoneId.AsphodelosTheFourthCircleSavage,
    overrideTimelineFile: true,
    timelineFile: 'P4S.txt',
    initData: () => {
        return {
            colorHeadmarkerIds: [],
            传毒开关:false,
            第二次传毒:false,
            第二次踩塔:false,
            要传毒:false,
            要传毒2:false,
            要截线:false,
        };
    },
    timelineTriggers: [
        {
            id: 'P4S 传毒开',
            regex: /传毒开关:开/,
            run: (data)=> data.传毒开关 = true,
        },
        {
            id: 'P4S 传毒关',
            regex: /传毒开关:关/,
            run: (data)=> {
                data.传毒开关 = false;
                data.要传毒 = false;
                data.要传毒2 = false;
                data.要截线 = false;
            },
        },
        {
            id: 'P4S 去接毒',
            regex: /--debuffs--/,
            beforeSeconds: -1,
            condition: (data) => {
                return  data.要传毒 && !data.要传毒2;
            },
            alertText: '去接毒',
        },
        {
            id: 'P4S 挂机',
            regex: /--debuffs--/,
            beforeSeconds: 1,
            condition: (data) => !data.要传毒 && !data.要截线,
            infoText: '你什么都不用干，挂机吧!',
        },
        {
            id: 'P4S Role Call2',
            regex: /球连线/,
            beforeSeconds: 6.7,
            alertText: (data) => {
                return data.zhuangqiu;
            },
        },
        {
            id: 'P4S 踩塔去截线',
            regex: /报截线/,
            condition: (data) => {
                return  data.要截线;
            },
            alertText: '去截线',
        },

        //本体
        {
            id: 'P4S Dark Design',
            regex: /放置黄圈/,
            beforeSeconds: 5,
            infoText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'Stack for Puddle AOEs',
                    de: 'Stacken (Pfützen)',
                    fr: 'Packez les zones au sol d\'AoEs',
                    ja: '真ん中で頭割り',
                    cn: '集合放置黄圈',
                    ko: '중앙에 모이기',
                },
            },
        },
        {
            id: 'P4S 另一个红D',
            regex: /放置黄圈/,
            beforeSeconds: 8,
            condition: (data)=> data.二运红D.includes(data.me) ,
            infoText: (data) => {
                let a = '';
                if (data.二运红D[0] == data.me)
                    a = data.二运红D[1]
                else
                    a = data.二运红D[0]
                return '另一个红D：'+nametocnjob(a,data);
            },
            durationSeconds: 10,
        },
        {
            id: 'P4S Kothornos Kick',
            regex: /超级跳/,
            beforeSeconds: 5.3,
            infoText: (data, _matches, output) => {
                let jumpDir = '';
                if (data.jumpDir1 === '左← (引导)，右→ (踩塔)')
                    jumpDir = !data.kickTwo ? output.west() : output.east();
                else if (data.jumpDir1 === '右← (引导)，左→ (踩塔)')
                    jumpDir = !data.kickTwo ? output.east() : output.west();
                else
                    return output.baitJump();
                return output.baitJumpDir({ dir: jumpDir });
            },
            run: (data) => data.kickTwo = true,
            outputStrings: {
                baitJumpDir: {
                    en: 'Bait Jump ${dir}?',
                    de: 'Sprung ködern ${dir}?',
                    fr: 'Attirez le saut ${dir}?',
                    ja: 'ジャンプ誘導 ${dir}?',
                    cn: '引导跳跃 ${dir}',
                    ko: '점프 유도 ${dir}?', // FIXME
                },
                baitJump: {
                    en: 'Bait Jump?',
                    de: 'Sprung ködern?',
                    fr: 'Attirez le saut?',
                    ja: 'ジャンプ誘導?',
                    cn: '引导跳跃',
                    ko: '점프 유도',
                },
                east: '右→',
                west: '左←',
                unknown: Outputs.unknown,
            },
        },
        {
            id: 'P4S Kothornos Quake',
            regex: /大地摇动/,
            beforeSeconds: 5,
            infoText: (data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'Bait Earthshakers?',
                    de: 'Erdstoß ködern?',
                    fr: 'Orientez les secousses ?',
                    ja: 'アスシェイカー誘導?',
                    cn: '大地摇动',
                    ko: '어스세이커 유도?',
                },
            },
        },
        {
            id: 'P4S Hemitheos\'s Water IV',
            regex: /击退 IV/,
            beforeSeconds: 5,
            alertText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'Middle Knockback',
                    de: 'Rückstoß von der Mitte',
                    fr: 'Poussée au milieu',
                    ja: '真ん中でノックバック',
                    cn: '防击退',
                    ko: '중앙에서 넉백',
                },
            },
        },
        {
            id: 'P4S 6运',
            regex: /6运/,
            run:(data)=>{
                data.六运先后 = [];
            },
        },
        {
            id: 'P4S 6运报拉线1',
            regex: /第1组1 出去/,
            beforeSeconds: 0.5,
            condition: (data)=> data.六运先后 !== [] && data.六运点名 === '12.00' && data.六运先后.includes(data.role),
            alarmText: sixTTS,
        },
        {
            id: 'P4S 6运报拉线2',
            regex: /第1组2 出去/,
            beforeSeconds: 1,
            condition: (data)=> data.六运先后 !== [] && data.六运点名 === '12.00' && !data.六运先后.includes(data.role),
            alarmText: sixTTS,
        },
        {
            id: 'P4S 6运报拉线3',
            regex: /第2组1 出去/,
            beforeSeconds: 1,
            condition: (data)=> data.六运先后 !== [] && data.六运点名 === '22.00' && data.六运先后.includes(data.role),
            alarmText: sixTTS,
        },
        {
            id: 'P4S 6运报拉线4',
            regex: /第2组2 出去/,
            beforeSeconds: 1,
            condition: (data)=> data.六运先后 !== [] && data.六运点名 === '22.00' && !data.六运先后.includes(data.role),
            alarmText: sixTTS,
        },
        {
            id: 'P4S 6运报拉线5',
            regex: /第3组1 出去/,
            beforeSeconds: 1,
            condition: (data)=> data.六运先后 !== [] && data.六运点名 === '32.00' && data.六运先后.includes(data.role),
            alarmText: sixTTS,
        },
        {
            id: 'P4S 6运报拉线6',
            regex: /第3组2 出去/,
            beforeSeconds: 1,
            condition: (data)=> data.六运先后 !== [] && data.六运点名 === '32.00' && !data.六运先后.includes(data.role),
            alarmText: sixTTS,
        },
        {
            id: 'P4S 6运报拉线7',
            regex: /第4组1 出去/,
            beforeSeconds: 1,
            condition: (data)=> data.六运先后 !== [] && data.六运点名 === '42.00' && data.六运先后.includes(data.role),
            alarmText: sixTTS,
        },
        {
            id: 'P4S 6运报拉线8',
            regex: /第4组2 出去/,
            beforeSeconds: 1,
            condition: (data)=> data.六运先后 !== [] && data.六运点名 === '42.00' && !data.六运先后.includes(data.role),
            alarmText: sixTTS,
        },
    ],


    triggers: [
        {
            id: 'P4S Headmarker Tracker',
            type: 'HeadMarker',
            netRegex: NetRegexes.headMarker({}),
            condition: (data) => data.decOffset === undefined && data.act === undefined,
            // Unconditionally set the first headmarker here so that future triggers are conditional.
            run: (data, matches) => getHeadmarkerId(data, matches),
        },
        {
            id: 'P4S Decollation',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6A09', capture: false }),
            response: Responses.aoe(),
        },
        {
            id: 'P4S Bloodrake',
            // AoE hits tethered players in first one, the non-tethered in second
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '69D8', capture: false }),
            preRun: (data) => {
                let _a; 
                return data.bloodrakeCounter = ((_a = data.bloodrakeCounter) !== null && _a !== void 0 ? _a : 0) + 1;
            },
            response: Responses.aoe(),
        },
        //报谁传毒，谁接线
        {
            id: 'P4S Bloodrake Store',
            type: 'Ability',
            netRegex: NetRegexes.ability({ id: '69D8' }),
            condition: (data)=> {return data.传毒开关},
            suppressSeconds: 1,
            infoText: (data, matches ) => {
                let role = data.role;
                let isDPS=false;
                if (role == 'dps')
                    isDPS = true;
                //第一次没连线的截线
                //第二次没连线的传毒
                if (!data.第二次传毒){
                    if (data.party.isDPS(matches.target)){
                        if (!isDPS)  data.要截线 = true;
                        return 'T奶截线';
                    };
                    if (isDPS)  data.要截线 = true;
                    return 'DPS截线';
                } else {
                    if (data.party.isDPS(matches.target)){
                        if (!isDPS)  data.要传毒 = true;
                        return 'T奶接毒';
                    }
                    if (isDPS)  data.要传毒 = true;
                    return 'DPS接毒';
                };
            },
            run: (data) => {
                data.第二次传毒 = !data.第二次传毒;
            },
        },
        //踩塔
        {
            id: 'P4S Belone Coils',
            // 69DE DPS踩塔，TN第一次截线，第二次传毒
            // 69DF TN踩塔，DPS第一次截线，第二次传毒
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: ['69DE', '69DF', '69E0', '69E1'] }),
            suppressSeconds: 1,
            alertText: (data,matches) => {
                let role = data.role;
                let isDPS=false;
                if (role == 'dps')
                    isDPS = true;
                if (!data.第二次踩塔){
                    if (matches.id == '69DE'){
                        if (!isDPS)  data.要截线 = true;
                        return 'DPS踩塔，T奶截线';
                    };
                    if (matches.id == '69DF'){
                        if (isDPS)  data.要截线 = true;
                        return 'T奶踩塔，DPS截线';
                    };
                }
                else{
                    if (matches.id == '69DE'){
                        if (!isDPS)  data.要传毒 = true;
                        return 'DPS踩塔，T奶接毒';
                    };
                    if (matches.id == '69DF'){
                        if (isDPS)  data.要传毒 = true;
                        return 'T奶踩塔，DPS接毒';
                    };
                };
                
            },
            run: (data) => {
                data.第二次踩塔 = !data.第二次踩塔;
            },
        },
        //报传毒
        {
            id: 'P4S Role Call',
            type: 'GainsEffect',
            netRegex: NetRegexes.gainsEffect({ effectId: 'AF2', capture: true }),
            condition: Conditions.targetIsYou(),
            run:(data)=>{data.要传毒2 = true},
        },
        //取消报拿毒
        {
            id: 'P4S Director\'s Belone',
            type: 'Ability',
            disabled:true,
            netRegex: NetRegexes.ability({ id: '69E6', capture: false }),
            // Delay callout until debuffs are out
            delaySeconds: 1.4,
        },
        //报截线
        {
            id: 'P4S Inversive Chlamys',
            // Possible a player still has not yet passed debuff
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '69ED', capture: false }),
            condition: (data) => {return data.要截线},
            alertText: '去截线',
        },
        {
            id: 'P4S Elegant Evisceration',
            // This one does an aoe around the tank
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6A08' }),
            response: Responses.tankBusterSwap('alert'),
        },


//剧场tts
        {
            id: 'P4S Levinstrike Pinax',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '69D7', capture: false }),
            durationSeconds: 6,
            alertText: '去场边',
        },
        {
            id: 'P4S Well Pinax',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '69D6', capture: false }),
            durationSeconds: 6,
            alertText: '击退击退',
        },
        {
            id: 'P4S Acid Pinax',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '69D4', capture: false }),
            alertText: '分散分散',
        },
        {
            id: 'P4S Lava Pinax',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '69D5', capture: false }),
            alertText: '分摊分摊',
        },

        {
            id: 'P4S Northerly Shift Slash',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6A02', capture: false }),
            alarmText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'North Cleave',
                    de: 'Cleave in den Norden',
                    fr: 'Cleave au nord',
                    ja: '北の横',
                    cn: '上↑A点 顺劈贴边',
                    ko: '북쪽 칼 휘두르기',
                },
            },
        },
        {
            id: 'P4S Easterly Shift Slash',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6A04', capture: false }),
            alarmText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'East Cleave',
                    de: 'Cleave in den Osten',
                    fr: 'Cleave à l\'est',
                    ja: '東の横',
                    cn: '右→B点 顺劈贴边',
                    ko: '동쪽 칼 휘두르기',
                },
            },
        },
        {
            id: 'P4S Southerly Shift Slash',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6A03', capture: false }),
            alarmText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'South Cleave',
                    de: 'Cleave in den Süden',
                    fr: 'Cleave au sud',
                    ja: '南の横',
                    cn: '下↓C点 顺劈贴边',
                    ko: '남쪽 칼 휘두르기',
                },
            },
        },
        {
            id: 'P4S Westerly Shift Slash',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6A05', capture: false }),
            alarmText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'West Cleave',
                    de: 'Cleave in den Westen',
                    fr: 'Cleave à l\'ouest',
                    ja: '西の横',
                    cn: '左←D点 顺劈贴边',
                    ko: '서쪽 칼 휘두르기',
                },
            },
        },
        {
            id: 'P4S Northerly Shift Cape',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '69FD', capture: false }),
            alarmText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'North Cape',
                    de: 'Umhang im Norden',
                    fr: 'Cape au nord',
                    ja: '北でノックバック',
                    cn: '上↑A点 防击退',
                    ko: '북쪽 망토',
                },
            },
        },
        {
            id: 'P4S Easterly Shift Cape',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '69FF', capture: false }),
            alarmText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'East Cape',
                    de: 'Umhang im Osten',
                    fr: 'Cape à l\'est',
                    ja: '東でノックバック',
                    cn: '右→B点 防击退',
                    ko: '동쪽 망토',
                },
            },
        },
        {
            id: 'P4S Southerly Shift Cape',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '69FE', capture: false }),
            alarmText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'South Cape',
                    de: 'Umhang im Süden',
                    fr: 'Cape au sud',
                    ja: '南でノックバック',
                    cn: '下↓C点 防击退',
                    ko: '남쪽 망토',
                },
            },
        },
        {
            id: 'P4S Westerly Shift Cape',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6A00', capture: false }),
            alarmText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'West Cape',
                    de: 'Umhang im Westen',
                    fr: 'Cape à l\'ouest',
                    ja: '西でノックバック',
                    cn: '左←D点 防击退',
                    ko: '서쪽 망토',
                },
            },
        },
        {
            id: 'P4S Well Pinax Knockback',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '69D6'}),
            disabled:true,
        },
        {
            id: 'P4S Directional Shift Knockback',
            // Callout Knockback during Levinstrike + Shift
            type: 'StartsUsing',
            disabled:true,
            netRegex: NetRegexes.startsUsing({ id: ['69FD', '69FE', '69FF', '6A00'] }),
            condition: (data) => !data.wellShiftKnockback,
            delaySeconds: (data, matches) => parseFloat(matches.castTime) - 5,
            response: Responses.knockback(),
            run: (data) => data.wellShiftKnockback = false,
        },
//剧场结束


        
        {
            id: 'P4S Acting Role',
            type: 'GainsEffect',
            netRegex: NetRegexes.gainsEffect({ effectId: ['B6D', 'B6E', 'B6F'], capture: true }),
            condition: Conditions.targetIsYou(),
            infoText: '站好位准备撞球',
            run: (data,mataches)=>{
                switch (mataches.effectId) {
                    case 'B6D':
                        data.zhuangqiu = '撞DPS球';
                        break;
                    case 'B6E':
                        data.zhuangqiu = '撞奶妈球';
                        break;
                    case 'B6F':
                        data.zhuangqiu = '撞T球';
                        break;
                }
            },
            
        },
        {
            id: 'P4S 撞球lets go',
            type: 'GainsEffect',
            netRegex: NetRegexes.gainsEffect({ effectId: ['B6D', 'B6E', 'B6F'], capture: false }),
            suppressSeconds: 1,
            delaySeconds: 25,
            alertText: "let's go",
            
        },
        {
            id: 'P4S Belone Bursts',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '69D9',  capture: false }),
            disabled:true,
        },
        {
            id: 'P4S Periaktoi',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: ['69F5', '69F6', '69F7', '69F8'] }),
            alertText: (_data, matches, output) => {
                const pinax = {
                    '69F5': output.acid(),
                    '69F6': output.lava(),
                    '69F7': output.well(),
                    '69F8': output.thunder(),
                };
                return output.text({ pinax: pinax[matches.id] });
            },
            outputStrings: {
                text: {
                    en: '${pinax} safe',
                    de: '${pinax} sicher',
                    fr: '${pinax} safe',
                    ja: '安置: ${pinax}',
                    cn: '${pinax} 安全',
                    ko: '안전한 곳: ${pinax}',
                },
                acid: {
                    en: 'Acid',
                    de: 'Gift',
                    fr: 'Poison',
                    ja: '毒/緑',
                    cn: '绿色毒',
                    ko: '독/녹색',
                },
                lava: {
                    en: 'Lava',
                    de: 'Lava',
                    fr: 'Feu',
                    ja: '炎/赤',
                    cn: '红色火',
                    ko: '불/빨강',
                },
                well: {
                    en: 'Well',
                    de: 'Brunnen',
                    fr: 'Eau',
                    ja: '水/白',
                    cn: '白色水',
                    ko: '물/하양',
                },
                thunder: {
                    en: 'Thunder',
                    de: 'Blitz',
                    fr: 'Foudre',
                    ja: '雷/青',
                    cn: '蓝色雷',
                    ko: '번개/파랑',
                },
            },
        },





        //本体
        {
            id: 'P4S Searing Stream',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6A2D', capture: false }),
            response: Responses.aoe(),
        },
        {
            //data.act记录第几运
            id: 'P4S Act Tracker',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: ['6A0C', '6EB[4-7]', '6A36'] }),
            preRun: (data, matches) => {
                const actMap = {
                    '6A0C': '1',
                    '6EB4': '2',
                    '6EB5': '3',
                    '6EB6': '4',
                    '6EB7': 'finale',
                    '6A36': 'curtain',
                };
                data.act = actMap[matches.id];
            },
            infoText: (data) => {
                let num = data.act;
                if (num == 'finale') num = 5;
                if (num == 'curtain') num = 6;
                return '第'+num+'次运动会';
            },
        },
        {
            //通过回调函数收集战斗单位数据
            id: 'P4S Thorns Collector',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6A0C' }),
            promise: async (data, matches, _output) => {
                // Collect all Hesperos entities up front
                let combatantName = null;
                combatantName = matches.source;
                let combatantData = null;
                if (combatantName) {
                    combatantData = await callOverlayHandler({
                        call: 'getCombatants',
                        names: [combatantName],
                    });
                }
                // if we could not retrieve combatant data, the
                // trigger will not work, so just resume promise here
                if (combatantData === null) {
                    console.error(`Hesperos: null data`);
                    return;
                }
                if (!combatantData.combatants) {
                    console.error(`Hesperos: null combatants`);
                    return;
                }
                const combatantDataLength = combatantData.combatants.length;
                if (combatantDataLength < 8) {
                    console.error(`Hesperos: expected at least 8 combatants got ${combatantDataLength}`);
                    return;
                }
                // the lowest eight Hesperos IDs are the thorns that tether the boss
                const sortCombatants = (a, b) => {
                    let _a; 
                    let _b; 
                    return ((_a = a.ID) !== null && _a !== void 0 ? _a : 0) - ((_b = b.ID) !== null && _b !== void 0 ? _b : 0);
                };
                const sortedCombatantData = combatantData.combatants.sort(sortCombatants).splice(combatantDataLength - 8, combatantDataLength);
                if (!sortedCombatantData)
                    throw new UnreachableCode();
                sortedCombatantData.forEach((combatant) => {
                    let _a; let _b;
                    ((_a = data.thornIds) !== null && _a !== void 0 ? _a : (data.thornIds = [])).push((_b = combatant.ID) !== null && _b !== void 0 ? _b : 0);
                });
            },
            run: (data) => {
                delete data.传毒开关;
                delete data.第二次传毒;
                delete data.第二次踩塔;
                delete data.要传毒;
                delete data.要传毒2;
                delete data.要截线;
                data.二运点名计数 = 0;
                data.二运已点名 = false;
                data.二运红D = [];
                data.五运踩塔开关 = false;
                data.六运点名 = '';
            },
        },
        {
            //一运安全点
            id: 'P4S Act One Safe Spots',
            type: 'Tether',
            netRegex: NetRegexes.tether({ id: '00AD'}),
            condition: (data) => data.act === '1',
            // Tethers come out Cardinals (0 seconds), (3s) Towers, (6s) Other Cardinals
            suppressSeconds: 7,
            alertText: (data, matches, output) => {
                let _a;
                const thorn = ((_a = data.thornIds) !== null && _a !== void 0 ? _a : (data.thornIds = [])).indexOf(parseInt(matches.sourceId, 16));
                const thornMap = {
                    4: '前后 安全',
                    5: '前后 安全',
                    6: '两边 安全',
                    7: '两边 安全',
                };
                return thornMap[thorn];
            },
        },
        {
            id: 'P4S Nearsight',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6A26', capture: false }),
            alertText: (data, _matches, output) => data.role === 'tank' ? output.tankbustersIn() : output.getOut(),
            outputStrings: {
                tankbustersIn: {
                    en: 'In (Tankbusters)',
                    de: 'Rein (Tankbusters)',
                    fr: 'À l\'intérieur (Tank busters)',
                    ja: 'タンク近づく',
                    cn: '靠近 (坦克死刑)',
                    ko: '탱커 안쪽으로',
                },
                getOut: '远离远离',
            },
        },
        {
            id: 'P4S Farsight',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6A27', capture: false }),
            alertText: (data, _matches, output) => data.role === 'tank' ? output.tankbustersOut() : output.getIn(),
            outputStrings: {
                tankbustersOut: {
                    en: 'Out (Tankbusters)',
                    de: 'Raus, tankbuster',
                    fr: 'À l\'extérieur (Tank busters)',
                    ja: 'タンク離れる',
                    cn: '远离 (坦克死刑)',
                    ko: '탱커 바깥쪽으로',
                },
                getIn: '靠近靠近',
            },
        },
        {
            id: 'P4S Demigod Double',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6E78'}),
            condition: Conditions.caresAboutPhysical(),
            response: Responses.sharedTankBuster(),
        },

        {   //二运安全点
            id: 'P4S Act Two Safe Spots',
            type: 'Tether',
            netRegex: NetRegexes.tether({ id: '00AD'}),
            condition: (data) => data.act === '2',
            // Tethers come out Cardinals (0 seconds), (3s) Other Cardinals
            suppressSeconds: 4,
            alertText: (data, matches) => {
                let _a;
                const thorn = ((_a = data.thornIds) !== null && _a !== void 0 ? _a : (data.thornIds = [])).indexOf(parseInt(matches.sourceId, 16));
                const thornMap = {
                    0: '前后 安全',
                    1: '前后 安全',
                    2: '前后 安全',
                    3: '前后 安全',
                    4: '两边 安全',
                    5: '两边 安全',
                    6: '两边 安全',
                    7: '两边 安全',
                };
                return thornMap[thorn];
            },
        },
        {
            id: 'P4S Color Headmarker Collector',
            type: 'HeadMarker',
            netRegex: NetRegexes.headMarker({}),
            condition: (data) => data.decOffset === undefined && data.act !== undefined,
            // Gather headmarkers in Act 2
            run: (data, matches) => {
                const id = parseInt(matches.id, 16);
                data.colorHeadmarkerIds.push(id);
            },
        },
        {
            id: 'P4S Color Headmarkers',
            type: 'HeadMarker',
            netRegex: NetRegexes.headMarker({}),
            condition: (data) => data.act == '2' || data.act == '4',
            // Delay some for headmarkers to be gathered
            delaySeconds: (data) => data.decOffset ? 0 : 0.3,
            response: (data, matches, output) => {
                let num = data.act;
                if (num == 'finale') num = 5;
                if (num == 'curtain') num = 6;
                num = num*1;

                let _a; let _b;
                // cactbot-builtin-response
                output.responseOutputStrings = tetherOutputStrings;
                // Calculate offset from purple headmarker in Act 2
                if (!data.decOffset) {
                    // Log message in case there isn't enough headmarkers
                    // Doable with 5 as the first headmarker on missing target to be removed is two greens
                    if (data.colorHeadmarkerIds.length < 5)
                        console.error(`Act ${(_a = data.act) !== null && _a !== void 0 ? _a : 'Unknown'}: Found ${data.colorHeadmarkerIds.length} headmarkers in Act 2, expected at least 5! Assumed one was purple.`);
                    // Sort IDs, relying on purple at index 0 for offset calculation
                    data.colorHeadmarkerIds.sort((a, b) => a - b);
                    data.decOffset = ((_b = data.colorHeadmarkerIds[0]) !== null && _b !== void 0 ? _b : 0) - purpleMarker;
                }
                const id = getHeadmarkerId(data, matches);
                if (id == '012F' && data.party.isDPS(matches.target))     //如果你是红D，告诉你另一个红D是谁
                        data.二运红D.push(matches.target);
                const headMarkers = {
                    '012C': output.blueTether(),
                    '012D': output.purpleTether(),
                    '012E': output.greenTether(),
                    '012F': output.orangeTether(),
                };
                const headMarkersAct = {
                    '012C': tetherOutputStringsAct.blueTether,
                    '012D': tetherOutputStringsAct.purpleTether,
                    '012E': tetherOutputStringsAct.greenTether,
                    '012F': tetherOutputStringsAct.orangeTether,
                };
                if (matches.target === data.me) {
                    data.二运已点名 = true;
                    return { 
                        infoText: ()=> {
                            return headMarkers[id]+headMarkersAct[id][num]
                        } 
                    };
                };
                //没点名的那个孤儿和紫色连线，所以也报紫色
                if (data.二运已点名 == false && data.二运点名计数 == 6){
                    data.二运已点名 = true;
                    return { infoText: '紫色远离' };
                };
            },
            run: (data)=> {
                data.二运点名计数 = data.二运点名计数 + 1;
            },
        },
        {
            id: 'P4S Ultimate Impulse',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6A2C', capture: false }),
            response: Responses.bigAoe(),
        },
        {
            id: 'P4S Act Three Bait Order',
            type: 'Tether',
            netRegex: NetRegexes.tether({ id: '00AD' }),
            condition: (data) => data.act === '3',
            // Tethers come out East or West (0 seconds), (3s) Middle knockack, (6) Opposite Cardinal
            suppressSeconds: 7,
            infoText: (data, matches, output) => {
                let _a; let _b;
                const thorn = ((_a = data.thornIds) !== null && _a !== void 0 ? _a : (data.thornIds = [])).indexOf(parseInt(matches.sourceId, 16));
                const thornMapDirs = {
                    0: '左← (引导)，右→ (踩塔)',
                    1: '左← (引导)，右→ (踩塔)',
                    2: '左← (引导)，右→ (踩塔)',
                    3: '左← (引导)，右→ (踩塔)',
                    4: '右→ (引导)，左← (踩塔)',
                    5: '右→ (引导)，左← (踩塔)',
                    6: '右→ (引导)，左← (踩塔)',
                    7: '右→ (引导)，左← (踩塔)',
                };
                data.jumpDir1 = thornMapDirs[thorn];
                return thornMapDirs[thorn];
            },
        },
        {
            id: 'P4S Heart Stake',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6A2B' }),
            condition: Conditions.caresAboutPhysical(),
            response: Responses.tankBuster(),
        },
        {
            id: 'P4S Wreath of Thorns 5',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6A34', capture: false }),
            infoText: (_data, _matches, output) => output.text(),
            outputStrings: {
                text: {
                    en: 'Spread at tethered thorn',
                    de: 'Verteilen bei der Dornenhecke',
                    fr: 'Dispersez-vous vers une épine liée',
                    ja: '結ばれた羽の方で散開',
                    cn: '在自己连线位置分散',
                    ko: '연결된 가시 덤불 주위 산개',
                },
            },
        },
        {
            id: 'P4S Fleeting Impulse',
            type: 'Ability',
            netRegex: NetRegexes.ability({ id: '6A1C' }),
            preRun: (data, _matches) => {
                let _a;
                data.fleetingImpulseCounter = ((_a = data.fleetingImpulseCounter) !== null && _a !== void 0 ? _a : 0) + 1;
            },
            // ~22.3 seconds between #1 Fleeting Impulse (6A1C) to #1 Hemitheos's Thunder III (6A0E)
            // ~21.2 seconds between #8 Fleeting Impulse (6A1C) to #8 Hemitheos's Thunder III (6A0E).
            // Split the difference with 22 seconds.
            alertText: (data, matches, output) => {
                if (matches.target === data.me){
                    data.五运计数 = data.fleetingImpulseCounter;
                    return output.text({ num: data.fleetingImpulseCounter });
                }
            },
            outputStrings: {
                text: {
                    en: '${num}',
                    de: '${num}',
                    fr: '${num}',
                    ja: '羽: ${num}番目',
                    cn: '第${num} 第${num}',
                    ko: '가시: ${num}번째',
                },
            },
            run:(data)=>{
                data.五运踩塔开关 = true;                
            },
        },
        {
            id: 'P4S 5运踩塔',
            type: 'Tether',
            netRegex: NetRegexes.tether({ id: '00AD' }),
            condition: (data) => data.act === 'finale' && data.五运踩塔开关,
            suppressSeconds: 7,
            alarmText : (data, matches) => {
                let _a; 
                const thorn = ((_a = data.thornIds) !== null && _a !== void 0 ? _a : (data.thornIds = [])).indexOf(parseInt(matches.sourceId, 16));
                const thornMapDirs = {
                    0: '↖(左上)',
                    1: '←(左边)',
                    2: '↙(左下)',
                    3: '↓(下边)',
                    4: '↘(右下)',
                    5: '→(右边)',
                    6: '↗(右上)',
                    7: '↑(上边)',
                };
                let i = thorn - data.五运计数 + 1;
                if (i < 0)
                    i = 8 + i;
                return thornMapDirs[i]+' 踩塔';
            },
        },
        {   //6运报buff
            id: 'P4S Curtain Call Debuffs',
            // Durations could be 12s, 22s, 32s, and 42s
            type: 'GainsEffect',
            netRegex: NetRegexes.gainsEffect({ effectId: 'AF4', capture: true }),
            condition: (data, matches) => {
                return (data.me === matches.target && data.act === 'curtain');
            },
            response: (data, matches, output) => {
                // cactbot-builtin-response
                output.responseOutputStrings = curtainCallOutputStrings;
                data.curtainCallGroup = Math.ceil(((parseFloat(matches.duration)) - 2) / 10);
                if (data.curtainCallGroup === 1)
                    return { alarmText: output.group({ num: data.curtainCallGroup }) };
                return { infoText: output.group({ num: data.curtainCallGroup }) };
            },
            run: (data,matches)=>{
                data.六运点名 = matches.duration;
            },
        },
        {
            id: 'P4S 6运判断打法',
            type: 'Tether',
            netRegex: NetRegexes.tether({ id: '00AD' }),
            condition: (data) => data.act === 'curtain',
            suppressSeconds: 300,
            run:(data,matches)=>{
                if (data.party.isDPS(matches.source))
                    data.六运先后 = ['dps'];
                else data.六运先后 = ['tank','healer'];
            },
        },
        {
            //万变水波不报
            id: 'P4S Hell\'s Sting',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6A1E', capture: false }),
            disabled:true,
        },
        {
            id: 'P4S Curtain Call Reminders',   
            type: 'GainsEffect',
            netRegex: NetRegexes.gainsEffect({ effectId: 'B7D', capture: true }),
            disabled:true,
        },
    ],
});
