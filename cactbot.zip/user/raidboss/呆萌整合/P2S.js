const firstHeadmarker = parseInt('0103', 16);
const getHeadmarkerId = (data, matches) => {
    if (typeof data.decOffset === 'undefined')
        data.decOffset = parseInt(matches.id, 16) - firstHeadmarker;
    return (parseInt(matches.id, 16) - data.decOffset).toString(16).toUpperCase().padStart(4, '0');
};

var lianxianT;     //储存接线的T
var dust2;         //储存dust2次数



Options.Triggers.push({
    zoneId: ZoneId.AsphodelosTheSecondCircleSavage,
    overrideTimelineFile: true,
    timelineFile: 'P2S.txt',
    timelineTriggers: [
        {
            id: 'P2S dust2_1',
            regex: '第一次 箭头对冲',
            beforeSeconds: 5,
            infoText: '第一次对冲',
            run: ()=> dust2 = 1,
        },
        {
            id: 'P2S dust2_2',
            regex: '第二次 箭头对冲',
            beforeSeconds: 5,
            infoText: '第二次对冲',
            run: ()=> dust2 = 2,
        },
        {
            id: 'P2S dust2_3',
            regex: '第三次 箭头对冲',
            beforeSeconds: 5,
            infoText: '第三次对冲',
            run: ()=> dust2 = 3,
        },
        {
            id: 'P2S 集合放黄圈',
            regex: '集合放黄圈',
            beforeSeconds: 8,
            suppressSeconds: 30,
            infoText: '集合放黄圈',
        },
    ],
    triggers: [
        {
            id: 'P2S Headmarker Tracker',
            type: 'HeadMarker',
            netRegex: NetRegexes.headMarker({}),
            condition: (data) => data.decOffset === undefined,
            // Unconditionally set the first headmarker here so that future triggers are conditional.
            run: (data, matches) => getHeadmarkerId(data, matches),
        },
        {
            id: 'P2S Murky Depths',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6833', capture: false }),
            response: Responses.aoe(),
        },
        {
            id: 'P2S Doubled Impact',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6832' }),
            response: Responses.sharedTankBuster(),
        },
        {
            id: 'P2S Sewage Deluge',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6810', capture: false }),
            response: Responses.bigAoe(),
        },
        {
            id: 'P2S Spoken Cataract',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: ['6817', '6811', '6812', '6813'],  capture: false }),
            suppressSeconds: 1,
            alertText: (_data, _matches, output) => output.directions(),
            outputStrings: {
                directions: {
                    en: 'Back of head',
                    de: 'Zur Rückseite des Kopfes',
                    fr: 'Derrière la tête',
                    ja: '頭の後ろへ',
                    cn: '去头后面',
                    ko: '뒤통수 쪽으로',
                },
            },
        },
        {
            id: 'P2S Winged Cataract',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: ['6814', '6815', '6818', '6816'],  capture: false }),
            suppressSeconds: 1,
            alertText: (_data, _matches, output) => output.directions(),
            outputStrings: {
                directions: {
                    en: 'Front of head',
                    de: 'Zur Vorderseite des Kopfes',
                    fr: 'Devant la tête',
                    ja: '頭の前へ',
                    cn: '去头前面',
                    ko: '바라보는 쪽으로',
                },
            },
        },
        {
            id: 'P2S Ominous Bubbling',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '682B',  capture: false }),
            delaySeconds: 3,
            suppressSeconds: 1,
            infoText: (_data, _matches, output) => output.groups(),
            outputStrings: {
                groups: {
                    en: 'Healer Groups',
                    de: 'Heiler-Gruppen',
                    fr: 'Groupes sur les heals',
                    ja: 'ヒラに頭割り',
                    cn: '与奶妈分摊',
                    ko: '힐러 그룹 쉐어',
                },
            },
        },
        {
            id: 'P2S Mark of the Tides',
            type: 'GainsEffect',
            netRegex: NetRegexes.gainsEffect({ effectId: 'AD0' }),
            condition: Conditions.targetIsYou(),
            alertText: (_data, matches, output) => output.awayFromGroup(),
            outputStrings: {
                awayFromGroup: Outputs.awayFromGroup,
            },
        },
        {
            id: 'P2S Mark of the Depths',
            type: 'GainsEffect',
            netRegex: NetRegexes.gainsEffect({ effectId: 'AD1' }),
            condition: Conditions.targetIsYou(),
            alertText: (_data, matches, output) => output.stackOnYou(),
            outputStrings: {
                stackOnYou: Outputs.stackOnYou,
            },
        },
        {
            id: 'P2S Channeling Flow',
            type: 'GainsEffect',
            netRegex: NetRegexes.gainsEffect({ effectId: ['AD2', 'AD3', 'AD4', 'AD5'] }),
            condition: Conditions.targetIsYou(),
            alertText: (_data, matches) => {
                const t = parseFloat(matches.duration);
                if (dust2 == 1)
                    return '对冲';
                if (dust2 == 2){
                    if (t < 15)
                        return '先对冲，后放圈';
                    return '先放圈，后对冲';
                };
                if (dust2 == 3){
                    if (t < 15)
                        return '先对冲，后集合';
                    return '先集合，后对冲';
                };
            },
        },
        {
            // Aoe from head outside the arena
            id: 'P2S Dissociation',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '682E'}),
            alertText: (_data, matches, output) => {
                const xCoord = parseFloat(matches.x);
                if (xCoord > 100)
                    return output.w();
                if (xCoord < 100)
                    return output.e();
            },
            outputStrings: {
                e: '←左半场安全',
                w: '→右半场安全',
            },
        },
        {
            // Spread aoe marker on some players, not all
            id: 'P2S Tainted Flood',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '6838'}),
            condition: (data, matches) => matches.target === data.me,
            response: Responses.spread(),
        },
        {
            id: 'P2S Coherence Flare',
            type: 'Tether',
            netRegex: NetRegexes.tether({ id: '0054'}),
            condition: (data) => data.role == 'tank',
            suppressSeconds:20,
            infoText: '坦克接线',
        },
        {
            id: 'P2S 判定连线T',
            type: 'Tether',
            netRegex: NetRegexes.tether({ id: '0054'}),
            run: (data, matches) => lianxianT = matches.target,
        },
        {
            id: 'P2S Coherence Stack',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '681B'}),
            // 12 second cast, delay for tether to settle
            delaySeconds: (_data, matches) => parseFloat(matches.castTime) - 6,
            alertText: (data, _matches, output) => {
                if (lianxianT !== data.me){
                    if (data.role === 'tank')
                        return output.flareLineTank();
                    return output.flareLineStack();
                };
            },
            outputStrings: {
                flareLineStack: {
                    en: 'Line Stack (behind tank)',
                    de: 'Linien-Sammeln (hinter dem Tank)',
                    fr: 'Package en ligne (derrière le tank)',
                    ja: '直線頭割り（タンクより後）',
                    cn: '直线分摊，站坦克后面',
                    ko: '탱커 뒤로 직선 쉐어',
                },
                flareLineTank: {
                    en: 'Line Stack (be in front)',
                    de: 'Linien-Sammeln (vorne sein)',
                    fr: 'Package en ligne (Placez-vous devant)',
                    ja: '直線頭割り（みんなの前に）',
                    cn: '直线分摊，站人群前面',
                    ko: '직선 쉐어 맨 앞으로',
                },
            },
        },
        {
            // Raidwide knockback -> dont get knocked into slurry
            id: 'P2S Shockwave',
            type: 'StartsUsing',
            netRegex: NetRegexes.startsUsing({ id: '682F' }),
            // 7.7 cast time, delay for proper arm's length
            delaySeconds: (_data, matches) => parseFloat(matches.castTime) - 5,
            alertText: '防击退',
        },
        {
            id: 'P2S Kampeos Harma Marker',
            type: 'HeadMarker',
            netRegex: NetRegexes.headMarker({}),
            condition: Conditions.targetIsYou(),
            response: (data, matches) => {
                const id = getHeadmarkerId(data, matches);
                if (!id)
                    return;
                const harmaMarkers = [
					'0091',
					'0092',
					'0093',
					'0094',
					'0095',
					'0096',
					'0097',
					'0098',
				];
                if (!harmaMarkers.includes(id))
                    return;
                let num = parseInt(id) - 90;
                switch (num){
                    case 1: return {'alarmText': '1号(连线)，去BOOS对面，站内侧' };
                    case 2: return {'alarmText': '2号(连线)，去BOOS脚下，站内侧' };
                    case 3: return {'alarmText': '3号(连线)，去BOOS对面，站外侧' };
                    case 4: return {'alarmText': '4号(连线)，去BOOS脚下，站外侧' };
                    case 5: return {'alarmText': '1号(无连线)，站边上' };
                    case 6: return {'alarmText': '2号(无连线)，站边上' };
                    case 7: return {'alarmText': '3号(无连线)，站边上' };
                    case 8: return {'alarmText': '4号(无连线)，站边上' };
                };
            },
        },
    ],
});
